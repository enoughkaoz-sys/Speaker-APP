import React from "react";
import { Pressable, Text, ViewStyle } from "react-native";

export function Btn({
  title,
  onPress,
  variant = "solid",
  style,
  disabled,
}: {
  title: string;
  onPress: () => void;
  variant?: "solid" | "outline";
  style?: ViewStyle;
  disabled?: boolean;
}) {
  const base: ViewStyle = {
    padding: 14,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  };
  const solid: ViewStyle = { backgroundColor: "#0B0B0F" };
  const outline: ViewStyle = { borderWidth: 1, borderColor: "rgba(255,255,255,0.16)" };
  const textColor = variant === "solid" ? "#FFFFFF" : "#FFFFFF";
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        base,
        variant === "solid" ? solid : outline,
        { opacity: disabled ? 0.5 : pressed ? 0.85 : 1 },
        style,
      ]}
    >
      <Text style={{ color: textColor, fontWeight: "800" }}>{title}</Text>
    </Pressable>
  );
}
