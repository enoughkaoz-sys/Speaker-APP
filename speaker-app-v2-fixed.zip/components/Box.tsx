import React from "react";
import { View, ViewStyle } from "react-native";

export function Box({ style, children }: { style?: ViewStyle; children: React.ReactNode }) {
  return <View style={[{ padding: 14, borderWidth: 1, borderRadius: 14, borderColor: "rgba(255,255,255,0.12)" }, style]}>{children}</View>;
}
