import React from "react";
import { SafeAreaView, ViewStyle } from "react-native";

export function Screen({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return (
    <SafeAreaView style={[{ flex: 1, backgroundColor: "#050508" }, style]}>
      {children}
    </SafeAreaView>
  );
}
