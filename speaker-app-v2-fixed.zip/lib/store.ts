import * as SecureStore from "expo-secure-store";

const KEY = "speaker_v2_store_v1";

export type LocalStore = {
  items: any[];
  invoices: any[];
  ledger: any[];
};

const empty: LocalStore = { items: [], invoices: [], ledger: [] };

export async function loadStore(): Promise<LocalStore> {
  const raw = await SecureStore.getItemAsync(KEY);
  if (!raw) return empty;
  try {
    const parsed = JSON.parse(raw);
    return { ...empty, ...parsed };
  } catch {
    return empty;
  }
}

export async function saveStore(store: LocalStore) {
  await SecureStore.setItemAsync(KEY, JSON.stringify(store));
}
