import { Item } from "./types";
import { uid } from "./uid";

export const seedItems: Item[] = [
  // Vermute padrão (Cinzano / Martini)
  { id: uid(), name: "Cinzano Rosso", category: "Vermute", tier: "PADRAO", unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },
  { id: uid(), name: "Cinzano Bianco", category: "Vermute", tier: "PADRAO", unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },
  { id: uid(), name: "Cinzano Extra Dry", category: "Vermute", tier: "PADRAO", unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },
  { id: uid(), name: "Martini Rosso", category: "Vermute", tier: "PADRAO", unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },
  { id: uid(), name: "Martini Bianco", category: "Vermute", tier: "PADRAO", unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },
  { id: uid(), name: "Martini Extra Dry", category: "Vermute", tier: "PADRAO", unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },

  // Vermute premium (Dolin / Carpano)
  { id: uid(), name: "Dolin Rouge", category: "Vermute", tier: "PREMIUM", unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Dolin Dry", category: "Vermute", tier: "PREMIUM", unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Carpano Antica Formula", category: "Vermute", tier: "PREMIUM", unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },

  // Spirits
  { id: uid(), name: "Gin S.A.L", category: "Destilado", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Vodka S.A.L", category: "Destilado", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Tanqueray London Dry", category: "Destilado", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Tanqueray Ten", category: "Destilado", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Chivas 18", category: "Whisky", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },

  // Johnnie Walker family
  { id: uid(), name: "Johnnie Walker Red", category: "Whisky", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Johnnie Walker Black", category: "Whisky", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Johnnie Walker Double Black", category: "Whisky", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Johnnie Walker Green", category: "Whisky", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Johnnie Walker Gold", category: "Whisky", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },
  { id: uid(), name: "Johnnie Walker Blue", category: "Whisky", tier: null, unit_base: "ml", pack_size: 750, min_stock: 750, active: true },

  // Produção
  { id: uid(), name: "Cordial (Base)", category: "Produção", tier: null, unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },
  { id: uid(), name: "Switchel (Base)", category: "Produção", tier: null, unit_base: "ml", pack_size: 1000, min_stock: 1000, active: true },
  { id: uid(), name: "Ácido cítrico", category: "Insumo", tier: null, unit_base: "g", pack_size: 1000, min_stock: 500, active: true },
  { id: uid(), name: "Ácido málico", category: "Insumo", tier: null, unit_base: "g", pack_size: 1000, min_stock: 500, active: true },
  { id: uid(), name: "Açúcar refinado", category: "Insumo", tier: null, unit_base: "g", pack_size: 1000, min_stock: 1000, active: true },
];
