export type Role =
  | "GERENTE_EXECUTIVO"
  | "HEAD_BARTENDER"
  | "SOCIO_ADM"
  | "CONSULTOR_VENDAS"
  | "SOMMELIER_COCKTAILS";

export type ItemTier = "PADRAO" | "PREMIUM" | null;

export type Item = {
  id: string;
  name: string;
  category: string;
  tier: ItemTier;
  unit_base: "ml" | "g" | "un";
  pack_size: number;
  min_stock: number;
  active: boolean;
};

export type InvoiceDraft = {
  id: string;
  source: "XML" | "OCR" | "MANUAL";
  supplier_name: string;
  issued_at: string;
  raw_file_uri?: string;
  lines: Array<{
    raw_description: string;
    mapped_item_id?: string;
    qty_base: number;
    unit_cost: number;
  }>;
};
