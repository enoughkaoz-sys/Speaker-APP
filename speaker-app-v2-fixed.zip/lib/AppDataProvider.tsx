import React, { createContext, useContext } from "react";
import { useAppData } from "./useAppData";

const Ctx = createContext<ReturnType<typeof useAppData> | null>(null);

export function AppDataProvider({ children }: { children: React.ReactNode }) {
  const data = useAppData();
  return <Ctx.Provider value={data}>{children}</Ctx.Provider>;
}

export function useData() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useData must be used within AppDataProvider");
  return ctx;
}
