import { useEffect, useMemo, useState } from "react";
import { loadStore, saveStore, LocalStore } from "./store";
import { seedItems } from "./seed";
import { uid } from "./uid";
import { Item, InvoiceDraft } from "./types";

export type LedgerEntry = {
  id: string;
  item_id: string;
  type: "IN" | "OUT" | "ADJUST";
  qty_base: number;
  unit_cost?: number;
  reason?: string;
  actor?: string;
  created_at: string;
};

export function useAppData() {
  const [store, setStore] = useState<LocalStore | null>(null);

  useEffect(() => {
    (async () => {
      const s = await loadStore();
      if (!s.items?.length) {
        s.items = seedItems;
      }
      setStore(s);
      await saveStore(s);
    })();
  }, []);

  async function commit(next: LocalStore) {
    setStore(next);
    await saveStore(next);
  }

  const items: Item[] = (store?.items ?? []) as any;

  const balanceByItem = useMemo(() => {
    const map = new Map<string, number>();
    for (const it of items) map.set(it.id, 0);
    for (const e of (store?.ledger ?? []) as LedgerEntry[]) {
      const prev = map.get(e.item_id) ?? 0;
      const delta = e.type === "IN" ? e.qty_base : -Math.abs(e.qty_base);
      map.set(e.item_id, prev + delta);
    }
    return map;
  }, [store, items]);

  const criticalItems = useMemo(() => {
    return items.filter((it) => (balanceByItem.get(it.id) ?? 0) < (it.min_stock ?? 0));
  }, [items, balanceByItem]);

  async function createInvoiceDraft(from: { source: "XML" | "OCR"; supplier_name?: string; issued_at?: string; raw_file_uri?: string; lines?: any[] }) {
    if (!store) return null;
    const draft: InvoiceDraft = {
      id: uid(),
      source: from.source,
      supplier_name: from.supplier_name ?? "Fornecedor",
      issued_at: from.issued_at ?? new Date().toISOString().slice(0, 10),
      raw_file_uri: from.raw_file_uri,
      lines: from.lines ?? [],
    };
    const next = { ...store, invoices: [draft, ...(store.invoices ?? [])] };
    await commit(next);
    return draft;
  }

  async function postInvoice(invoiceId: string, actor = "system") {
    if (!store) return;
    const invoices = (store.invoices ?? []) as InvoiceDraft[];
    const inv = invoices.find((x) => x.id === invoiceId);
    if (!inv) return;

    const now = new Date().toISOString();
    const entries: LedgerEntry[] = inv.lines
      .filter((l) => l.mapped_item_id && l.qty_base > 0)
      .map((l) => ({
        id: uid(),
        item_id: l.mapped_item_id!,
        type: "IN",
        qty_base: l.qty_base,
        unit_cost: l.unit_cost,
        reason: `Entrada (${inv.source})`,
        actor,
        created_at: now,
      }));

    const next = { ...store, ledger: [...entries, ...(store.ledger ?? [])] };
    await commit(next);
  }

  async function adjustItem(itemId: string, qtyDelta: number, reason: string, actor = "system") {
    if (!store) return;
    const now = new Date().toISOString();
    const entry: LedgerEntry = {
      id: uid(),
      item_id: itemId,
      type: "ADJUST",
      qty_base: Math.abs(qtyDelta),
      reason,
      actor,
      created_at: now,
    };
    // ADJUST treated as negative in balance calc; use qtyDelta sign? keep simple: if qtyDelta positive, record IN instead.
    const entry2: LedgerEntry = qtyDelta >= 0 ? { ...entry, type: "IN", reason } : entry;

    const next = { ...store, ledger: [entry2, ...(store.ledger ?? [])] };
    await commit(next);
  }

  return {
    ready: !!store,
    items,
    criticalItems,
    balanceByItem,
    invoices: (store?.invoices ?? []) as InvoiceDraft[],
    ledger: (store?.ledger ?? []) as LedgerEntry[],
    createInvoiceDraft,
    postInvoice,
    adjustItem,
    commit,
    store,
  };
}
