export function uid() {
  // Simple unique id for offline-first demo; replace with uuid in production.
  return Math.random().toString(16).slice(2) + Date.now().toString(16);
}
