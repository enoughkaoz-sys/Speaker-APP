import React from "react";
import { View, Text } from "react-native";
import { Screen } from "@/components/Screen";
import { Box } from "@/components/Box";

export default function Treinamentos() {
  return (
    <Screen>
      <View style={{ padding: 16, gap: 12 }}>
        <Text style={{ color: "white", fontSize: 22, fontWeight: "900" }}>Treinamentos</Text>
        <Box>
          <Text style={{ color: "white", fontWeight: "800" }}>V1</Text>
          <Text style={{ color: "rgba(255,255,255,0.75)" }}>
            Conteúdo entra no próximo passo (carregar textos e PDFs).
          </Text>
        </Box>
      </View>
    </Screen>
  );
}
