import React from "react";
import { View, Text } from "react-native";
import { useRouter } from "expo-router";
import { Screen } from "@/components/Screen";
import { Box } from "@/components/Box";
import { Btn } from "@/components/Btn";
import { useData } from "@/lib/AppDataProvider";

export default function Estoque() {
  const router = useRouter();
  const { criticalItems } = useData();

  return (
    <Screen>
      <View style={{ padding: 16, gap: 12 }}>
        <Text style={{ color: "white", fontSize: 22, fontWeight: "900" }}>Estoque</Text>

        <Box>
          <Text style={{ color: "white", fontWeight: "800" }}>Crítico</Text>
          <Text style={{ color: "rgba(255,255,255,0.75)" }}>
            {criticalItems.length} itens abaixo do mínimo
          </Text>
        </Box>

        <Btn title="Entrada (XML)" onPress={() => router.push("/(tabs)/entrada?mode=xml")} />
        <Btn title="Entrada (Câmera) — V1.1" variant="outline" onPress={() => router.push("/(tabs)/entrada?mode=ocr")} />

        <Btn title="Ver itens" variant="outline" onPress={() => router.push("/(tabs)/itens")} />
      </View>
    </Screen>
  );
}
