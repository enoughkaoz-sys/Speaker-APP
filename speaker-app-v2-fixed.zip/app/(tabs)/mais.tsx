import React from "react";
import { View, Text } from "react-native";
import { Screen } from "@/components/Screen";
import { Box } from "@/components/Box";

export default function Mais() {
  return (
    <Screen>
      <View style={{ padding: 16, gap: 12 }}>
        <Text style={{ color: "white", fontSize: 22, fontWeight: "900" }}>Mais</Text>
        <Box>
          <Text style={{ color: "white", fontWeight: "800" }}>Permissões</Text>
          <Text style={{ color: "rgba(255,255,255,0.75)" }}>
            RBAC entra no próximo passo (cargos definidos já).
          </Text>
        </Box>
      </View>
    </Screen>
  );
}
