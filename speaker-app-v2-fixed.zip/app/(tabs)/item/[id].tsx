import React, { useMemo } from "react";
import { View, Text } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/Screen";
import { Box } from "@/components/Box";
import { Btn } from "@/components/Btn";
import { useData } from "@/lib/AppDataProvider";

export default function ItemDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { items, balanceByItem, adjustItem } = useData();

  const item = useMemo(() => items.find((x) => x.id === id), [items, id]);
  if (!item) {
    return (
      <Screen>
        <View style={{ padding: 16 }}>
          <Text style={{ color: "white" }}>Item não encontrado</Text>
        </View>
      </Screen>
    );
  }

  const bal = balanceByItem.get(item.id) ?? 0;

  return (
    <Screen>
      <View style={{ padding: 16, gap: 12 }}>
        <Text style={{ color: "white", fontSize: 22, fontWeight: "900" }}>{item.name}</Text>

        <Box>
          <Text style={{ color: "white", fontWeight: "800" }}>Saldo</Text>
          <Text style={{ color: "rgba(255,255,255,0.75)" }}>
            {bal} {item.unit_base} (mín: {item.min_stock} {item.unit_base})
          </Text>
        </Box>

        <Box>
          <Text style={{ color: "white", fontWeight: "800" }}>Categoria</Text>
          <Text style={{ color: "rgba(255,255,255,0.75)" }}>
            {item.category} {item.tier ? `• ${item.tier}` : ""}
          </Text>
        </Box>

        <Btn title="+ Entrada rápida (1 pack)" onPress={() => adjustItem(item.id, item.pack_size, "Ajuste rápido +", "mobile")} />
        <Btn title="- Saída rápida (1 pack)" variant="outline" onPress={() => adjustItem(item.id, -item.pack_size, "Ajuste rápido -", "mobile")} />
      </View>
    </Screen>
  );
}
