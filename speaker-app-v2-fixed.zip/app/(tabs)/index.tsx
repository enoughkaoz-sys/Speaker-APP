import React from "react";
import { View, Text } from "react-native";
import { Screen } from "@/components/Screen";
import { Box } from "@/components/Box";
import { useData } from "@/lib/AppDataProvider";

export default function Home() {
  const { criticalItems, ready } = useData();

  return (
    <Screen>
      <View style={{ padding: 16, gap: 12 }}>
        <Text style={{ color: "white", fontSize: 26, fontWeight: "900" }}>SPEAKER</Text>
        <Text style={{ color: "rgba(255,255,255,0.7)" }}>
          {ready ? "Operação pronta (V1 Estoque offline)" : "Carregando..."}
        </Text>

        <Box>
          <Text style={{ color: "white", fontWeight: "800" }}>Estoque crítico</Text>
          <Text style={{ color: "rgba(255,255,255,0.75)" }}>
            {criticalItems.length} itens abaixo do mínimo
          </Text>
        </Box>

        <Box>
          <Text style={{ color: "white", fontWeight: "800" }}>CMV</Text>
          <Text style={{ color: "rgba(255,255,255,0.75)" }}>
            Caixa automática entra na próxima etapa (quando conectar vendas + inventário).
          </Text>
        </Box>
      </View>
    </Screen>
  );
}
