import React, { useMemo } from "react";
import { View, Text, Pressable } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Screen } from "@/components/Screen";
import { Box } from "@/components/Box";
import { Btn } from "@/components/Btn";
import { useData } from "@/lib/AppDataProvider";

export default function EntradaPreview() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { invoices, items, postInvoice, commit, store } = useData();

  const inv = useMemo(() => invoices.find((x) => x.id === id), [invoices, id]);
  if (!inv) {
    return (
      <Screen>
        <View style={{ padding: 16 }}>
          <Text style={{ color: "white" }}>Rascunho não encontrado</Text>
        </View>
      </Screen>
    );
  }

  async function mapLine(index: number, itemId: string) {
    if (!store) return;
    const nextInvoices = invoices.map((x) => {
      if (x.id !== inv.id) return x;
      const lines = [...x.lines];
      lines[index] = { ...lines[index], mapped_item_id: itemId };
      return { ...x, lines };
    });
    await commit({ ...store, invoices: nextInvoices });
  }

  return (
    <Screen>
      <View style={{ padding: 16, gap: 12 }}>
        <Text style={{ color: "white", fontSize: 20, fontWeight: "900" }}>Prévia da Nota</Text>
        <Text style={{ color: "rgba(255,255,255,0.75)" }}>
          {inv.supplier_name} • {inv.issued_at} • {inv.source}
        </Text>

        <Box>
          <Text style={{ color: "white", fontWeight: "800" }}>Itens</Text>
          <Text style={{ color: "rgba(255,255,255,0.6)" }}>
            Toque em “Mapear” para ligar cada linha ao item do estoque.
          </Text>
        </Box>

        {inv.lines.map((l, idx) => {
          const mapped = items.find((it) => it.id === l.mapped_item_id);
          return (
            <Box key={idx} style={{ gap: 8 }}>
              <Text style={{ color: "white", fontWeight: "800" }}>
                {l.raw_description}
              </Text>
              <Text style={{ color: "rgba(255,255,255,0.75)" }}>
                qtd: {l.qty_base} • custo: {l.unit_cost}
              </Text>
              <Text style={{ color: "rgba(255,255,255,0.75)" }}>
                mapeado: {mapped ? mapped.name : "—"}
              </Text>

              <Pressable
                onPress={() => {
                  // V1: mapeia automaticamente para o primeiro item que contém alguma palavra (bem simples).
                  const guess = items.find((it) => l.raw_description.toLowerCase().includes(it.name.split(" ")[0].toLowerCase()));
                  mapLine(idx, (guess ?? items[0]).id);
                }}
                style={{ padding: 10, borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.16)" }}
              >
                <Text style={{ color: "white", fontWeight: "800" }}>Mapear (auto)</Text>
              </Pressable>
            </Box>
          );
        })}

        <Btn
          title="Confirmar entrada"
          onPress={async () => {
            await postInvoice(inv.id, "mobile");
            router.replace("/(tabs)/estoque");
          }}
        />
      </View>
    </Screen>
  );
}
