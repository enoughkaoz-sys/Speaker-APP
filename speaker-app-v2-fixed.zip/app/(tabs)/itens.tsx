import React, { useMemo, useState } from "react";
import { View, Text, TextInput, Pressable, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { Screen } from "@/components/Screen";
import { Box } from "@/components/Box";
import { useData } from "@/lib/AppDataProvider";

export default function Itens() {
  const router = useRouter();
  const { items, balanceByItem } = useData();
  const [q, setQ] = useState("");

  const data = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return items
      .filter((i) => !qq || i.name.toLowerCase().includes(qq) || i.category.toLowerCase().includes(qq))
      .sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
  }, [items, q]);

  return (
    <Screen>
      <View style={{ padding: 16, gap: 12 }}>
        <Text style={{ color: "white", fontSize: 22, fontWeight: "900" }}>Itens</Text>

        <TextInput
          value={q}
          onChangeText={setQ}
          placeholder="Buscar item ou categoria…"
          placeholderTextColor="rgba(255,255,255,0.4)"
          style={{
            borderWidth: 1,
            borderColor: "rgba(255,255,255,0.12)",
            borderRadius: 14,
            padding: 12,
            color: "white",
          }}
        />

        <FlatList
          data={data}
          keyExtractor={(it) => it.id}
          renderItem={({ item }) => {
            const bal = balanceByItem.get(item.id) ?? 0;
            return (
              <Pressable onPress={() => router.push(`/(tabs)/item/${item.id}`)} style={{ marginBottom: 10 }}>
                <Box>
                  <Text style={{ color: "white", fontWeight: "800" }}>
                    {item.name} {item.tier ? `• ${item.tier}` : ""}
                  </Text>
                  <Text style={{ color: "rgba(255,255,255,0.75)" }}>
                    {item.category} • saldo: {bal} {item.unit_base} • mín: {item.min_stock} {item.unit_base}
                  </Text>
                </Box>
              </Pressable>
            );
          }}
        />
      </View>
    </Screen>
  );
}
