import React, { useEffect } from "react";
import { View, Text } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as DocumentPicker from "expo-document-picker";
import { Screen } from "@/components/Screen";
import { Btn } from "@/components/Btn";
import { useData } from "@/lib/AppDataProvider";

export default function Entrada() {
  const router = useRouter();
  const { mode } = useLocalSearchParams<{ mode?: string }>();
  const { createInvoiceDraft } = useData();

  useEffect(() => {
    if (mode === "xml") pickXML();
  }, [mode]);

  async function pickXML() {
    const res = await DocumentPicker.getDocumentAsync({
      type: ["application/xml", "text/xml", "*/*"],
      copyToCacheDirectory: true,
      multiple: false,
    });
    if (res.canceled) return;

    // V1: cria rascunho com linhas vazias; no V1.1 parseia XML real via backend.
    const draft = await createInvoiceDraft({
      source: "XML",
      raw_file_uri: res.assets[0].uri,
      supplier_name: "Fornecedor",
      lines: [
        { raw_description: "Cinzano Rosso 1L", qty_base: 1000, unit_cost: 0 },
        { raw_description: "Gin S.A.L 750ml", qty_base: 750, unit_cost: 0 },
      ],
    });
    if (draft) router.replace({ pathname: "/(tabs)/entrada-preview", params: { id: draft.id } });
  }

  return (
    <Screen>
      <View style={{ padding: 16, gap: 12 }}>
        <Text style={{ color: "white", fontSize: 22, fontWeight: "900" }}>Entrada</Text>

        <Btn title="Anexar XML" onPress={pickXML} />
        <Btn title="Ler com câmera — V1.1" variant="outline" onPress={() => alert("OCR entra no V1.1")} />
      </View>
    </Screen>
  );
}
