import { Tabs } from "expo-router";
import { AppDataProvider } from "@/lib/AppDataProvider";

export default function TabsLayout() {
  return (
    <AppDataProvider>
      <Tabs screenOptions={{ headerShown: true, tabBarStyle: { backgroundColor: "#050508" }, tabBarActiveTintColor: "#FFFFFF", tabBarInactiveTintColor: "rgba(255,255,255,0.55)" }}>
        <Tabs.Screen name="index" options={{ title: "Início" }} />
        <Tabs.Screen name="estoque" options={{ title: "Estoque" }} />
        <Tabs.Screen name="itens" options={{ title: "Itens" }} />
        <Tabs.Screen name="entrada" options={{ title: "Entrada" }} />
        <Tabs.Screen name="treinamentos" options={{ title: "Treinamentos" }} />
        <Tabs.Screen name="mais" options={{ title: "Mais" }} />
      </Tabs>
    </AppDataProvider>
  );
}
